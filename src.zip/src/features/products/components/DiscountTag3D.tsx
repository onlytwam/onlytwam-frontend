import { useId } from "react";

interface DiscountTag3DProps {
  percent: number;
}

export default function DiscountTag3D({ percent }: DiscountTag3DProps) {
  const uid = useId().replace(/:/g, "");
  const pctText = `${Math.max(0, Math.round(percent))}%`;

  return (
    <div className="dt-ornament" aria-hidden="true">
      <svg
        className="dt-ornament-svg"
        viewBox="0 0 110 150"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id={`${uid}-silver`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fdfefe" />
            <stop offset="24%" stopColor="#dce2e8" />
            <stop offset="52%" stopColor="#8d96a0" />
            <stop offset="74%" stopColor="#f7fafc" />
            <stop offset="100%" stopColor="#6f7780" />
          </linearGradient>

          <linearGradient id={`${uid}-silverSoft`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="45%" stopColor="#cfd5dc" />
            <stop offset="100%" stopColor="#727a84" />
          </linearGradient>

          <radialGradient id={`${uid}-ivoryFace`} cx="30%" cy="18%" r="88%">
            <stop offset="0%" stopColor="#fffdfa" />
            <stop offset="52%" stopColor="#f7f2ea" />
            <stop offset="100%" stopColor="#e7ddd0" />
          </radialGradient>

          <linearGradient id={`${uid}-ivoryEdge`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#f3eadf" />
            <stop offset="100%" stopColor="#d2c3b3" />
          </linearGradient>

          <linearGradient id={`${uid}-lettering`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#b39272" />
            <stop offset="100%" stopColor="#8d6d52" />
          </linearGradient>

          <radialGradient id={`${uid}-holeDark`} cx="35%" cy="30%" r="75%">
            <stop offset="0%" stopColor="#808892" />
            <stop offset="72%" stopColor="#343941" />
            <stop offset="100%" stopColor="#111316" />
          </radialGradient>

          <filter id={`${uid}-tagShadow`} x="-30%" y="-30%" width="180%" height="190%">
            <feDropShadow dx="0" dy="7" stdDeviation="5" floodColor="#2f2b2a" floodOpacity="0.18" />
          </filter>

          <filter id={`${uid}-metalShadow`} x="-40%" y="-40%" width="180%" height="180%">
            <feDropShadow dx="0" dy="2" stdDeviation="1.8" floodColor="#1a1a1a" floodOpacity="0.18" />
          </filter>
        </defs>

        <g filter={`url(#${uid}-metalShadow)`}>
          <ellipse
            cx="19"
            cy="37"
            rx="21"
            ry="6.6"
            transform="rotate(-32 19 37)"
            fill="none"
            stroke={`url(#${uid}-silver)`}
            strokeWidth="2.1"
          />
        </g>

        <g filter={`url(#${uid}-metalShadow)`}>
          <circle cx="31" cy="24" r="12.2" fill={`url(#${uid}-silver)`} />
          <circle cx="27.5" cy="19.5" r="4.8" fill="rgba(255,255,255,0.56)" />
          <circle cx="31" cy="24" r="5" fill={`url(#${uid}-holeDark)`} />
        </g>

        <path
          d="M 34 29 C 40 37, 45 43, 52 50"
          fill="none"
          stroke={`url(#${uid}-silverSoft)`}
          strokeWidth="3.8"
          strokeLinecap="round"
          opacity="0.92"
        />

        <ellipse
          cx="53"
          cy="51"
          rx="7.9"
          ry="3.7"
          transform="rotate(24 53 51)"
          fill="none"
          stroke={`url(#${uid}-silver)`}
          strokeWidth="3.1"
          opacity="0.88"
        />

        <g transform="translate(38 50)" filter={`url(#${uid}-tagShadow)`}>
          <path
            d="M 10 0 H 36 L 48 12 V 90 H 0 V 12 Z"
            fill={`url(#${uid}-ivoryEdge)`}
            opacity="0.95"
            transform="translate(4 3)"
          />
          <path
            d="M 10 0 H 36 L 48 12 V 90 H 0 V 12 Z"
            fill={`url(#${uid}-ivoryFace)`}
            stroke="rgba(160, 142, 122, 0.35)"
            strokeWidth="1"
          />
          <path
            d="M 7 7 H 35 L 42 15 V 84 H 7 V 15 Z"
            fill="rgba(255,255,255,0.52)"
            opacity="0.42"
          />

          <g filter={`url(#${uid}-metalShadow)`}>
            <circle cx="24" cy="15.5" r="6.4" fill={`url(#${uid}-silver)`} />
            <circle cx="21.8" cy="13.4" r="2.3" fill="rgba(255,255,255,0.58)" />
            <circle cx="24" cy="15.5" r="3.2" fill={`url(#${uid}-holeDark)`} />
          </g>

          <text
            x="24"
            y="54"
            textAnchor="middle"
            fontFamily='"Palatino Linotype", Palatino, "Book Antiqua", Georgia, serif'
            fontSize="15"
            fontWeight="700"
            fill={`url(#${uid}-lettering)`}
            letterSpacing="0.3"
          >
            {pctText}
          </text>
          <text
            x="24"
            y="72"
            textAnchor="middle"
            fontFamily='"Palatino Linotype", Palatino, "Book Antiqua", Georgia, serif'
            fontSize="11.5"
            fontWeight="700"
            fill={`url(#${uid}-lettering)`}
            letterSpacing="1.9"
          >
            OFF
          </text>
        </g>

        <path
          d="M 37 32 C 44 39, 50 45, 60 54"
          fill="none"
          stroke={`url(#${uid}-silver)`}
          strokeWidth="3.7"
          strokeLinecap="round"
          opacity="0.96"
        />

        <ellipse
          cx="48"
          cy="48"
          rx="7.9"
          ry="3.7"
          transform="rotate(-18 48 48)"
          fill="none"
          stroke={`url(#${uid}-silver)`}
          strokeWidth="3.1"
          opacity="0.94"
        />

        <path
          d="M 8 40 C 13 46, 24 47, 31 42 C 36 37, 35 30, 29 26"
          fill="none"
          stroke={`url(#${uid}-silver)`}
          strokeWidth="2.1"
          strokeLinecap="round"
          opacity="0.94"
        />
      </svg>
    </div>
  );
}
